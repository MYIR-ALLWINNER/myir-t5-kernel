#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x2e1445dd, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xe6cb6cef, __VMLINUX_SYMBOL_STR(sensor_compat_ioctl32) },
	{ 0xd04a9d7e, __VMLINUX_SYMBOL_STR(sensor_s_parm) },
	{ 0x39b7fe4e, __VMLINUX_SYMBOL_STR(sensor_g_parm) },
	{ 0x4137c8c8, __VMLINUX_SYMBOL_STR(sensor_set_fmt) },
	{ 0x94e43ba3, __VMLINUX_SYMBOL_STR(sensor_get_fmt) },
	{ 0xb652817d, __VMLINUX_SYMBOL_STR(sensor_enum_frame_size) },
	{ 0x434f563b, __VMLINUX_SYMBOL_STR(sensor_enum_mbus_code) },
	{ 0x85ef8717, __VMLINUX_SYMBOL_STR(cci_dev_exit_helper) },
	{ 0x889d93e7, __VMLINUX_SYMBOL_STR(cci_dev_init_helper) },
	{ 0x5dbb61e2, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x490053f, __VMLINUX_SYMBOL_STR(__mutex_init) },
	{ 0xd303d69f, __VMLINUX_SYMBOL_STR(v4l2_ctrl_handler_free) },
	{ 0x740a6e5b, __VMLINUX_SYMBOL_STR(v4l2_ctrl_new_std) },
	{ 0x709c1118, __VMLINUX_SYMBOL_STR(v4l2_ctrl_handler_init_class) },
	{ 0xb2bfddc6, __VMLINUX_SYMBOL_STR(cci_dev_probe_helper) },
	{ 0xe06a9399, __VMLINUX_SYMBOL_STR(kmem_cache_alloc) },
	{ 0x8f678b07, __VMLINUX_SYMBOL_STR(__stack_chk_guard) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0xd5f28aa4, __VMLINUX_SYMBOL_STR(sensor_read) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x4829a47e, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xf82022d9, __VMLINUX_SYMBOL_STR(actuator_set_code) },
	{ 0x459df6b6, __VMLINUX_SYMBOL_STR(sensor_cfg_req) },
	{ 0x8ecdac47, __VMLINUX_SYMBOL_STR(actuator_init) },
	{ 0xfcb384aa, __VMLINUX_SYMBOL_STR(vin_set_pmu_channel) },
	{ 0x3d3bddb4, __VMLINUX_SYMBOL_STR(vin_gpio_set_status) },
	{ 0x8bfae72b, __VMLINUX_SYMBOL_STR(cci_unlock) },
	{ 0xde8b7cc1, __VMLINUX_SYMBOL_STR(vin_gpio_write) },
	{ 0x12a38747, __VMLINUX_SYMBOL_STR(usleep_range) },
	{ 0xd2ea2822, __VMLINUX_SYMBOL_STR(vin_set_mclk) },
	{ 0x5c203894, __VMLINUX_SYMBOL_STR(vin_set_mclk_freq) },
	{ 0x4c815c33, __VMLINUX_SYMBOL_STR(cci_lock) },
	{ 0x372d6a4b, __VMLINUX_SYMBOL_STR(sensor_write_array) },
	{ 0xd92cef7c, __VMLINUX_SYMBOL_STR(sensor_write) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x815ea3, __VMLINUX_SYMBOL_STR(cci_dev_remove_helper) },
	{ 0xb1a023af, __VMLINUX_SYMBOL_STR(to_state) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("i2c:gc5024_mipi");

MODULE_INFO(srcversion, "D6686BF983B081497665E75");
