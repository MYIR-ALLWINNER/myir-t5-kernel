cmd_drivers/media/platform/sunxi-vin/utility/cfg_op.o := /home/myir/t507h-android-0829/longan/out/gcc-linaro-5.3.1-2016.05-x86_64_aarch64-linux-gnu/bin/aarch64-linux-gnu-gcc -Wp,-MD,drivers/media/platform/sunxi-vin/utility/.cfg_op.o.d  -nostdinc -isystem /home/myir/t507h-android-0829/longan/out/gcc-linaro-5.3.1-2016.05-x86_64_aarch64-linux-gnu/bin/../lib/gcc/aarch64-linux-gnu/5.3.1/include -I./arch/arm64/include -I./arch/arm64/include/generated/uapi -I./arch/arm64/include/generated  -I./include -I./arch/arm64/include/uapi -I./include/uapi -I./include/generated/uapi -include ./include/linux/kconfig.h -D__KERNEL__ -mlittle-endian -Wall -Wundef -Wstrict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -Werror-implicit-function-declaration -Wno-format-security -std=gnu89 -fno-PIE -mgeneral-regs-only -DCONFIG_AS_LSE=1 -fno-asynchronous-unwind-tables -mpc-relative-literal-loads -fno-pic -fno-delete-null-pointer-checks -O2 --param=allow-store-data-races=0 -DCC_HAVE_ASM_GOTO -Wframe-larger-than=2048 -fstack-protector-strong -Wno-unused-but-set-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-var-tracking-assignments -g -Wdeclaration-after-statement -Wno-pointer-sign -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fno-stack-check -fconserve-stack -Werror=implicit-int -Werror=strict-prototypes -Werror=date-time -Werror=incompatible-pointer-types    -DKBUILD_BASENAME='"cfg_op"'  -DKBUILD_MODNAME='"vin_v4l2"' -c -o drivers/media/platform/sunxi-vin/utility/.tmp_cfg_op.o drivers/media/platform/sunxi-vin/utility/cfg_op.c

source_drivers/media/platform/sunxi-vin/utility/cfg_op.o := drivers/media/platform/sunxi-vin/utility/cfg_op.c

deps_drivers/media/platform/sunxi-vin/utility/cfg_op.o := \
    $(wildcard include/config/sensor/list.h) \

drivers/media/platform/sunxi-vin/utility/cfg_op.o: $(deps_drivers/media/platform/sunxi-vin/utility/cfg_op.o)

$(deps_drivers/media/platform/sunxi-vin/utility/cfg_op.o):
